public class Main {
    public static void main(String[] args) {
        String new_id = "=.=";
        Solution s1 = new Solution();
        s1.solution(new_id);
    }
}
